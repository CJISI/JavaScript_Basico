const name = "Cristian";
const edad = 30;
const developer = true;
const birthdate = new Date("april 3 1991");
const libro = {
    titulo:"Mujeres",
    author:"Bukowski",
    fecha: 1978,
    url: "https://www.casadellibro.com/libro-mujeres-18-ed/9788433920997/289838"
}

console.log(birthdate.getDay(),birthdate.getMonth()+1, birthdate.getFullYear())